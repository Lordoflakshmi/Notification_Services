﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Weir.Notification.Service.Helpers
{
    public static class NotificationMessages
    {
        public const string WorkorderNumber = "WorkorderNumber - ";
        public const string MovedRecievingToWorkorder = " has been moved from Receiving to Workorder.";
        public const string Saved = "Saved Successfully.";
        public const string Updated = "Updated Successfully.";
        public const string Receivingformfor = "Receiving form for ";
        public const string ReceivingformforCreated = "Created";
        public const string POReceivedforWorkorder = "PO Received for Work order";
        public const string SerialNumber = "Serial Number";
        public const string Setonhold = "set on hold";
        public const string Issettounhold = "is set to un-hold'";
        public const string VisualInspectionCompleted = "Visual Inspection has been completed for";
        public const string WorkorderClosed = " has been Closed";
        public const string PartNotAvailable = "Part Not Available for";
        public const string PartAvailable = "Part Available for";
        public const string RepairStatus = "set on Repair";
        public const string FinalInspectioncompleted = "Final Inspection completed for";        

    }
}
