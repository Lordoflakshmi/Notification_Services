﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Weir.Notification.Service.Helpers
{
    public static class NotificationEventsList
    {
        public const string ReceivingCreate = "ReceivingCreate";
        public const string ReceivePOApproval = "ReceivePOApproval";
        public const string OnHoldSerial = "OnHold-Serial";
        public const string OnHoldWO = "OnHold-WO";
        public const string UnHoldSerial = "UnHold-Serial";
        public const string UnHoldWO = "UnHold-WO";
        public const string VisualInsComplete = "Visual-Ins-Complete";
        public const string PartNotAvailableSerial = "Part-Not-Available-Serial";
        public const string PartAvailableSerial = "Part-Available-Serial";
        public const string FinalInspCompleteSerial = "Final-Insp-Complete-Serial";
        public const string WOClosure = "WO-Closure";
        public const string RepairSerial = "Repair-Serial";
        
    }
}
