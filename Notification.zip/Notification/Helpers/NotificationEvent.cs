﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Weir.Notification.Service.Helpers
{
    public class NotificationEvent
    {
        public enum FWTesting
        {
            ReceivingCreate = 1,
            ReceivePOApproval = 2,
            OnHold_Serial_Z_FW_Testing = 3,
            OnHold_WO_Z_FW_Testing = 4,
            UnHold_Serial_Z_FW_Testing = 5,
            UnHold_WO_Z_FW_Testing = 6,
            Visual_Ins_Complete_Z_FW_Testing = 7,
            Part_Not_Available_Serial_Z_FW_Testing = 8,
            Part_Available_Serial_Z_FW_Testing = 9,
            Final_Insp_Complete_Serial_Z_FW_Testing = 10,
            WO_Closure_Z_FW_Testing = 11,
            Repair_Serial_Z_FW_Testing = 12
        }

       
    }
}
