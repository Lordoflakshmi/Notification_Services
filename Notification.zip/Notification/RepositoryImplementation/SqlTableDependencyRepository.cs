﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weir.AMP.Core.DataAccess.Repository;
using Weir.Notification.Service.DTO.Request;
using Weir.Notification.Service.DTO.Response;
using Weir.Notification.Service.Model;
using Weir.Notification.Service.RepositoryContract;

namespace Weir.Notification.Service.RepositoryImplementation
{
   public class SqlTableDependencyRepository : ISqlTableDependencyRpository
    {
        private readonly Func<NotificationDbContext> _contextFactory;

        public Model.Notification Notification => GetEvent();

        public SqlTableDependencyRepository(Func<NotificationDbContext> context)
        {
            _contextFactory = context;
        }

        private Model.Notification GetEvent()
        {
            using (var context = _contextFactory.Invoke())
            {                
                return context.Notification.FirstOrDefault();
            }
        }        
    }
}
