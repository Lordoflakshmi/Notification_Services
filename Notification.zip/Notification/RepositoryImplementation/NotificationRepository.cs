﻿using System;
using System.Collections.Generic;
using System.Text;
using Weir.AMP.Core.DataAccess.Repository;
using Weir.Notification.Service.Model;
using Weir.Notification.Service.RepositoryContract;

namespace Weir.Notification.Service.RepositoryImplementation
{
    public class NotificationRepository : RepositoryBase, INotificationRepository
    {
        public NotificationRepository(NotificationDbContext dbContext)
                   : base(dbContext)
        {

        }
    }
}
