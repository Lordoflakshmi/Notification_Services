﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Weir.Notification.Service.DTO.Request
{
    public class MoveReceivingToWorkorderEventRequest
    {
        public string User { get; set; }
        public string WorkorderNumber { get; set; }
    }
}
