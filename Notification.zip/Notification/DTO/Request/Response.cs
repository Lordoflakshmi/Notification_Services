﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Weir.Notification.Service.DTO.Request
{
    public class Response
    {
        public string Message { get; set; }
        public object Content { get; set; }
        public bool Status { get; set; }
    }
}
