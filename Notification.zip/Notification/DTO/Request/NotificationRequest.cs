﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Weir.Notification.Service.DTO.Request
{
   public class NotificationRequest
    {       
        public string SubscriptionEvent { get; set; }
        public string Message { get; set; }
        public int RequestedById { get; set; }
        public List<CustUsers> CustomerUsers { get; set; }
    }
}
