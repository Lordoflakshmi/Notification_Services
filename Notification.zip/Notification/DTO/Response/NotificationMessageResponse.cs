﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Weir.Notification.Service.DTO.Response
{
    public class NotificationMessageResponse
    {
        public Guid Id { get; set; }
        public long SubscriptionEventId { get; set; }
        public long SubscriptionId { get; set; }
        public string Message { get; set; }
        public long CreatedBy { get; set; }
    }
}
