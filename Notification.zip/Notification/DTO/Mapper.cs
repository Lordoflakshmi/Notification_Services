﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using Weir.Notification.Service.DTO.Request;
using Weir.Notification.Service.DTO.Response;
using Weir.Notification.Service.Model;

namespace Weir.Notification.Service.DTO
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            CreateMap<MoveSentNotificationRequest, NotificationSent>();
            CreateMap<NotificationMessageResponse, MoveSentNotificationRequest>();
        }
    }
}
