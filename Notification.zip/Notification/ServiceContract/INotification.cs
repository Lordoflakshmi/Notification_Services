﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Weir.Notification.Service.DTO.Request;
using Weir.Notification.Service.DTO.Response;

namespace Weir.Notification.Service.ServiceContract
{
    public interface INotification
    {        
        public Task<Response> AddNotificatonAsync(NotificationRequest notificationRequest);
        public Task<Response> MoveSentNotification(MoveSentNotificationRequest moveSentNotificationRequest);
        public Task<List<string>> GetNotificationUsersAsync(long SubscriptionEventID);
        public Task<NotificationMessageResponse> GetNotificationMessageAsync(long SubscriptionEventID);
    }
}
