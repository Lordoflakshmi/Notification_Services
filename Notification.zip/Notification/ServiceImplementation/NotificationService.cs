﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Weir.Notification.Service.DTO.Request;
using Weir.Notification.Service.Helpers;
using Weir.Notification.Service.ServiceContract;
using Weir.Notification.Service.Model;
using Weir.Notification.Service.RepositoryContract;
using AutoMapper;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Weir.Notification.Service.DTO.Response;

namespace Weir.Notification.Service.ServiceImplementation
{
    public class NotificationService : INotification
    {
        private readonly INotificationRepository notificationRepository;
        private readonly IMapper mapper;
        public NotificationService(INotificationRepository _notificationRepository, IMapper _mapper)
        {
            this.notificationRepository = _notificationRepository;
            this.mapper = _mapper;
        }

        #region public async Task<Response> AddNotificatonAsync(NotificationRequest notificationRequest, long requestedById)
        public async Task<Response> AddNotificatonAsync(NotificationRequest notificationRequest)
        {
            var response = new Response() { Message = NotificationMessages.Saved, Status = true };

            var subscriptionEvent = await notificationRepository.Query<SubscriptionEvent>()
                     .Where(e => e.Event == notificationRequest.SubscriptionEvent && e.IsActive).FirstOrDefaultAsync();               
                   

            Model.Notification notificaiton = new Model.Notification();
            notificaiton.SubscriptionEventId = subscriptionEvent.Id;
            notificaiton.Message = notificationRequest.Message;
            notificaiton.CreatedBy = notificationRequest.RequestedById;
            notificaiton.CreatedDate = DateTime.UtcNow;
            notificationRepository.Add(notificaiton);
          
            return (new Response() { Content = new { Id = notificaiton.Id }, Message = NotificationMessages.Saved, Status = true });            
        }
        #endregion

        #region public Task<MoveSentNotificationRequest> MoveSentNotification()
        public async Task<Response> MoveSentNotification(MoveSentNotificationRequest moveSentNotificationRequest)
        {
            var response = new Response() { Status = true };

            var notificationToDelete = await notificationRepository.Query<Model.Notification>()
                .Where(e => e.Id == moveSentNotificationRequest.Id)
                .FirstOrDefaultAsync();

            var mappedNotificationSent = mapper.Map<NotificationSent>(moveSentNotificationRequest);
            mappedNotificationSent.SentTime = DateTime.UtcNow;
            mappedNotificationSent.CreatedDate = DateTime.UtcNow;

            notificationRepository.Delete(notificationToDelete);
            notificationRepository.AddAsync(mappedNotificationSent);

            return response;
        }
        #endregion

        #region public async Task<List<string>> GetNotificationUsersAsync(long subscriptionEventId)
        public async Task<List<string>> GetNotificationUsersAsync(long subscriptionEventId)
        {
            var notificaitonDetail = new List<string>();
            notificaitonDetail = await notificationRepository.Query<Model.EventNotificationUser>()
                    .Join(notificationRepository.Query<SubscriptionEvent>(), enu => enu.SubscriptionEventId, se => se.Id, (enu, se) => new { enu, se })
                    .Join(notificationRepository.Query<Subscription>(), x => x.se.SubscriptionId, s => s.Id, (x, s) => new { x, s })
                    .Where(e => e.x.enu.SubscriptionEventId == subscriptionEventId && e.s.IsActive)
                    .Select(s => s.x.enu.RecipientUserId)
                    .ToListAsync();            

            return notificaitonDetail;
        }
        #endregion

        #region public async Task<string> GetNotificationMessageAsync(long SubscriptionEventID)
        public async Task<NotificationMessageResponse> GetNotificationMessageAsync(long SubscriptionEventID)
        {
            var notificaitonDetail = await notificationRepository.Query<Model.Notification>()
                    .Join(notificationRepository.Query<SubscriptionEvent>(), n => n.SubscriptionEventId, se => se.Id, (n, se) => new { n, se })
                    .Join(notificationRepository.Query<Subscription>(), x => x.se.SubscriptionId, s => s.Id, (x, s) => new { x, s })
                    .Where(e => e.x.n.SubscriptionEventId == SubscriptionEventID && e.s.IsActive)
                    .OrderBy(o => o.x.n.CreatedDate)
                    .Select(r => new NotificationMessageResponse()
                    {
                        Id = r.x.n.Id,
                        SubscriptionId = r.s.Id,
                        SubscriptionEventId = r.x.n.SubscriptionEventId,
                        Message = r.x.n.Message,
                        CreatedBy = r.x.n.CreatedBy
                    }).FirstOrDefaultAsync();

            return notificaitonDetail;
        }
        #endregion        
    }
}
