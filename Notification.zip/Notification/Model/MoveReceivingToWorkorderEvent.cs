﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Weir.Notification.Service.Model
{
    public class MoveReceivingToWorkorderEvent
    {
        public List<string> UserIds { get; set; }
        public string Message { get; set; }
    }
}
