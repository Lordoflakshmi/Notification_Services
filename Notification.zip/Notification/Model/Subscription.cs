﻿using System;
using System.Collections.Generic;

namespace Weir.Notification.Service.Model
{
    public partial class Subscription
    {
        public Subscription()
        {
            NotificationSent = new HashSet<NotificationSent>();
            SubscriptionEvent = new HashSet<SubscriptionEvent>();
        }

        public long Id { get; set; }
        public string Username { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public bool IsActive { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual ICollection<NotificationSent> NotificationSent { get; set; }
        public virtual ICollection<SubscriptionEvent> SubscriptionEvent { get; set; }
    }
}
