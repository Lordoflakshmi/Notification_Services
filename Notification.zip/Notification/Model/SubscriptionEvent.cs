﻿using System;
using System.Collections.Generic;

namespace Weir.Notification.Service.Model
{
    public partial class SubscriptionEvent
    {
        public SubscriptionEvent()
        {
            EventNotificationUser = new HashSet<EventNotificationUser>();
            Notification = new HashSet<Notification>();
            NotificationSent = new HashSet<NotificationSent>();
        }

        public long Id { get; set; }
        public long SubscriptionId { get; set; }
        public string Event { get; set; }
        public bool IsActive { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual Subscription Subscription { get; set; }
        public virtual ICollection<EventNotificationUser> EventNotificationUser { get; set; }
        public virtual ICollection<Notification> Notification { get; set; }
        public virtual ICollection<NotificationSent> NotificationSent { get; set; }
    }
}
