﻿using System;
using System.Collections.Generic;

namespace Weir.Notification.Service.Model
{
    public partial class Notification
    {
        public Guid Id { get; set; }
        public long SubscriptionEventId { get; set; }
        public string Message { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual SubscriptionEvent SubscriptionEvent { get; set; }
    }
}
