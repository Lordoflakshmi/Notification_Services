﻿using System;
using System.Collections.Generic;
using System.Text;
using Weir.AMP.Core.DataAccess.Interface;

namespace Weir.Notification.Service.RepositoryContract
{
    public interface INotificationRepository: IRepositoryBase
    {
    }
}
