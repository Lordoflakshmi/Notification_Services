﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Weir.AMP.Core.DataAccess.Interface;
using Weir.Notification.Service.DTO.Request;
using Weir.Notification.Service.DTO.Response;
using Weir.Notification.Service.Model;

namespace Weir.Notification.Service.RepositoryContract
{
    public interface ISqlTableDependencyRpository
    {
        Model.Notification Notification { get; }        
    }
}
