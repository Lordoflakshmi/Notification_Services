﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Weir.Notification.Service.SqlTableDependencies
{
    public interface IDatabaseSubscription
    {
      public void Configure(string connectionString);

    }
}
